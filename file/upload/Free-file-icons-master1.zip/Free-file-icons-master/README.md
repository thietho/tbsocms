Free Icon Set for files
================================

A free icon set with vector images for popular extensions:
AAC, AI, AIFF, AVI, C, CPP, CSS, DAT, DMG, DOC, EXE, FLV, GIF, H, HPP, HTML,
ICS, JAVA, JPG, KEY, MID, MP3, MP4, MPG, PDF, PHP, PNG, PPT, PSD, PY, QT,
RAR, RB, RTF, SQL, TIFF, TXT, WAV, XLS, XML, YML, ZIP.

All icons are also offered in 512x512px, 48x48px, 32x32px.

These icons are an extract of [Teambox project manager](http://www.teambox.com/ "Project Management").
Designed for Teambox Technologies S.L. (2009)

Teambox is a collaboration web application built on Ruby on Rails.

Visit [Teambox website](http://teambox.com/ "Project Management")
for documentation, community and support: <http://teambox.com/>

Teambox: Project Management and Collaboration software
-------

- Website: <http://teambox.com/>
- Copyright: (cc) 2009 Teambox Technologies
- License: MIT License

LICENSE
-------

Copyright (C) 2009. Teambox Technologies, S.L.

The MIT License (MIT)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
